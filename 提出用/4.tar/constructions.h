//
// Created by world on 2019/12/07.
//
#include "string_info.h"
void ConstructSMatrix(string_s * s_i, int matsize);
void ConstructTout(string_out *t_out, char *t_in);
void ConstructTin(string_out *t_in, char *t_temp);
