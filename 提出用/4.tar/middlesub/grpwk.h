#pragma once

#include "../string_info.h"
#include "../linked_list.h"

#define BM_TO 16
#define AHO_TO 11

char *grpwk(char *t, string_s *s, int len);
